<?php

namespace App\Http\Controllers\Front;

use App\Http\Controllers\Controller;
use App\Models\Contents;
use App\Models\Footers;
use App\Models\images;
use App\Models\Lists;

use View;


use Illuminate\Http\Request;

class MainPageController extends Controller
{
    //

    public function index(){
        $socialmedia=Footers::select('facebook','whatsapp','instgram','twitter','Images','Tittle')->get();

        return view('Frontweb.page1',compact('socialmedia'));
    }
    public function interiorde​sign()
    {
        
        $mainsection=Contents::select('Images','Tittle')->where('id', 69)->get();
        $mainsectionCompontent= Contents::select('Paragraph1','Paragraph2')->where('section_id',1)->get();
        $about1=Contents::select('Images','Paragraph1','Paragraph2')->where('section_id', 3)->get();
        $aboutmain=Contents::select('Images','Paragraph1')->where('section_id', 4)->get();
        $servicess=Contents::select('Images','Tittle')->where('section_id', 7)->get();
        $testemonials=Contents::select('Images','Tittle','Paragraph1','Paragraph2')->where('section_id', 8)->get();
        $website=Footers::select('Images','Tittle','address','phone','email')->get();
        $socialmedia=Footers::select('facebook','whatsapp','instgram','twitter','Images','Tittle')->get();

        $aboutus1=Contents::select('Images','Tittle','Paragraph1')->where('id', 104)->get();
        $aboutus2=Contents::select('Images','Tittle','Paragraph1')->where('id', 105)->get();
        $aboutus3=Contents::select('Images','Tittle','Paragraph1')->where('id', 106)->get();

        $lists=Lists::select('list')->where('section_id',4)->get();

        return view('Frontweb.page3', compact('mainsection','aboutus1','lists','aboutus2','aboutus3','mainsectionCompontent','about1','aboutmain','servicess','testemonials','website', 'socialmedia'))->with('site',$website,'social',$socialmedia);
    
    }

    public function furniture()
    {
        $images = images::select('images')->where('section_id', 9)->get();
        $website=Footers::select('Images','Tittle','address','phone','email')->get();
        $socialmedia=Footers::select('facebook','whatsapp','instgram','twitter','Images','Tittle')->get();
        return view('Frontweb.page2' , compact('images','website','socialmedia'));
    }


    public function exteriordesign()
    {
        $Mainsection=Contents::select('Images','Tittle','Paragraph1','updated_at')->where('section_id', 10)->get();

        $aboutsec1=Contents::select('Images','Paragraph1','Paragraph2')->where('section_id', 11)->get();
        $aboutsec3=Contents::select('Images','Paragraph1','Paragraph2')->where('section_id', 13)->get();

        $services1=Contents::select('Images','Tittle')->where('section_id', 14)->get();
        $services2=Contents::select('Tittle','Paragraph1')->where('section_id', 15)->get();
        $services3=Contents::select('Images','Paragraph1','Paragraph2','updated_at')->where('section_id', 17)->get();
        $projects=images::select('images','beforImg')->where('section_id', 16)->where('id',22)->get();

        $aboutusTwo=Contents::select('Images','Paragraph1','updated_at')->where('id', 89)->get();
        $aboutusTwoo=Contents::select('Images','Paragraph1','updated_at')->where('id', 90)->get();
        $aboutusTwooo=Contents::select('Images','Paragraph1','updated_at')->where('id', 91)->get();

        $website=Footers::select('Images','Tittle','address','phone','email')->get();
        $socialmedia=Footers::select('facebook','whatsapp','instgram','twitter','Images','Tittle')->get();

        return view('Frontweb.page4', compact('Mainsection','aboutsec1','aboutsec3','services1','services2','services3','projects','website','socialmedia','aboutusTwo','aboutusTwoo','aboutusTwooo'));
    }
}

<?php

namespace App\Http\Controllers\Front\page3;

use App\Http\Controllers\Controller;
use App\Http\Responses\ViewResponse;
use App\Http\Requests\Backend\Home\MainsectionRequest;
use App\Models\Contents;
use App\Models\images;

use Illuminate\Http\Request;
class ProjectController extends Controller
{
    //
    //
    /**
    * @param \App\Http\Requests\Backend\Home\MainsectionRequest $request
    *
    * @return ViewResponse
    */
    public function showProjects()
    {
        $query=images::select('id','images','beforImg','updated_at')->where('section_id', 16);
        if(request()->ajax()) {
            return datatables()->of($query)
            ->addColumn('actions', 'ButtonPage3.project-action')
            ->rawColumns(['actions'])
            ->addIndexColumn()
            ->make(true);
        }
        return view('backend.page2.projects');  
    }

    public function createtProjects(Request $request)
    {

        $this->validate($request, [
 
            'Images' => 'required',
            'Images.*' => 'image|mimes:jpeg,png,jpg,gif,svg'
         
        ]);
        
        if ($request->hasFile('Images') AND $request->hasFile('Imagesb'))
        {
            $file1=$request->file('Images');
            $file2=$request->file('Imagesb');

            $name1 = time().rand(1,100).'.'.$file1->extension();
            $name2 = time().rand(1,100).'.'.$file2->extension();

            $file1->move(public_path('img'), $name1); 
            $file2->move(public_path('img'), $name2);    
            
            $contents   =   images::Create(
                [
                    'section_id'=>'16',
                    'images' => $name1,
                    'beforImg'=>$name2,
                 ]);  
        }  
        else{
            return redirect()->back()->with(['success' => 'User deleted successfully !']);

        }
    
        $contents->save();
 
    }

   public function storetProjects(Request $request)
   { 
       $ContentsId = $request->id;
       if ($request->hasFile('Images') AND $request->hasFile('Imagesb'))
        {
            $file1=$request->file('Images');
            $file2=$request->file('Imagesb');

            $name1 = time().rand(1,100).'.'.$file1->extension();
            $name2 = time().rand(1,100).'.'.$file2->extension();

            $file1->move(public_path('img'), $name1); 
            $file2->move(public_path('img'), $name2);    
            
            $contents   =   images::find($ContentsId);
            $contents->images=$name1;
            $contents->beforImg=$name2;
            $contents->save(); 
        }  
       else{
           $contents= images::find($ContentsId);
           $aftar = images::select('images')->where('id' , $ContentsId)->get();
           $before = images::select('beforImg')->where('id' , $ContentsId)->get();
           $contents->images=$aftar;
           $contents->beforImg=$before;           
       }

       

       return redirect()->back()->with(['flash_success' => __('alerts.backend.blog-category.created')]);

   }

   public function edittProjects(Request $request)
   {   
       $where = array('id' => $request->id);
       $company  = images::find($where)->first();
     
       return Response()->json($company);
   }

  
   public function destroyProjects(Request $request)
   {
       $contents = images::where('id',$request->id)->delete();
     
       return Response()->json($contents);
   }

}
